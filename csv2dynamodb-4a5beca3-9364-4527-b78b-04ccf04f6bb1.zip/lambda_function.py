import json
import csv
import boto3

def lambda_handler(event, context):
    region = 'us-east-2'
    record_list = []
    
    try:
        s3_client = boto3.client('s3')
        
        dynamodb = boto3.client('dynamodb', region_name = region)

        bucket = event['Records'][0]['s3']['bucket']['name']
        key = event['Records'][0]['s3']['object']['key']
        
        csv_file = s3_client.get_object(Bucket = bucket, Key = key)
        
        record_list = csv_file["Body"].read().decode('utf-8-sig').split('\n')
        
        csv_reader = csv.reader(record_list, delimiter=',')
        
        
        for row in csv_reader:
            Row_ID = row[0]
            Product_ID = row[1]
            Product_Category = row[2]
            Product_SubCategory = row[3]
            Product_Name = row[4]
            
            insertDB = dynamodb.put_item(TableName = 'auto_inventory', Item={
                'Row_ID' : {"S" : str(Row_ID)},
                'Product_ID': {'S': str(Product_ID)},
                'Product_Category' : {'S': str(Product_Category)},
                'Product_SubCategory': {'S': str(Product_SubCategory)},
                'Product_Name': {'S': str(Product_Name)}
                })
                
        print('Successfully added the records to the DynamoDB Table')
        
    except Exception as e:
        print(str(e))
    
    return {
        'statusCode': 200,
        'body': json.dumps('CSV to DynamoDB Success')
    }
