import json
import requests

def lambda_handler(event, context):
    # TODO implement
    API_Endpoint = "https://mp9lbij406.execute-api.us-east-2.amazonaws.com/default/dynamodb2json"
    response = requests.get(API_Endpoint)
    data = response.json()
    
    # return {
    #     'statusCode': 200,
    #     'body': json.dumps(data)
    # }
    return {'body' : json.dumps(data, sort_keys=True, indent = 4)}
# {
#         'statusCode': 200,
#         'body': data,
#         'headers' : {
#             'Content-Type' : 'application/json',
#         },
#     }
# for making json pretty ^
# ,sort_keys=True, indent=4