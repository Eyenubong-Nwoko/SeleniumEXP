import json
import boto3
from boto3.dynamodb.conditions import Key, Attr

def lambda_handler(event, context):
    region = 'us-east-2'
    dynamodb = boto3.resource('dynamodb', region_name = region)
    table = dynamodb.Table('auto_inventory')
    response = table.scan(FilterExpression=Attr('Product_Category').eq('Furniture') & Attr('Product_SubCategory').eq('Bookcases'))
    items = response['Items']
    
    print(type(items))
    # while 'LastEvaluatedKey' in response:
    #     response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
    #     items.extend(response['Items'])
    
    return {
        'statusCode': 200,
        'body': json.dumps(items,sort_keys=True, indent=4),
        'headers' : {
            'Content-Type' : 'application/json',
        },
    }
